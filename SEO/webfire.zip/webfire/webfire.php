<?php
/*
  Plugin Name: WebFire
  Plugin URI: http://webfire.com
  Description: Setup keywords in important SEO tags - title, keywords, description
  Version: 1.6
  Author: WebFire
  Author URI: http://webfire.com
 */

// updater, only run while admin panel displayed                
add_action('admin_init', 'webfire_auto_update');
function webfire_auto_update()
{
    require_once 'wp_autoupdate.php';

    $wptuts_plugin_current_version = '1.6';
    $wptuts_plugin_remote_path = 'http://tsunamisites.com/arbitrage/update_webfire.php';
    $wptuts_plugin_slug = plugin_basename(__FILE__);

    new webfire_auto_update($wptuts_plugin_current_version, $wptuts_plugin_remote_path, $wptuts_plugin_slug);
}

// modify the title
add_filter('wp_title', 'webfire_title', 10, 2);
function webfire_title($title, $sep)
{
    if (is_feed())
    {
        return $title;
    }

    global $post;

    if ( is_front_page() )
    {
        $webfire_title = get_option('webfire_home_title');
    }
    else
    {
        $webfire_title = get_post_meta($post->ID, '_webfire_title', true);
    }

    return empty($webfire_title) ? $title : $webfire_title;
}

// add the meta description and meta keywords
add_action('wp_head', 'webfire_head');
function webfire_head()
{
    global $post;
    
    $viewport       = get_option('webfire_viewport');
    $site_wide      = get_option('webfire_sitewide_head');
    $schema         = get_option('webfire_schema_head');
    
    if ( is_front_page() )
    {
        $description    = get_option('webfire_home_description');
        $keywords       = get_option('webfire_home_keywords');
        
    }
    else
    {
        $description    = get_post_meta($post->ID, '_webfire_description', true);
        $keywords       = get_post_meta($post->ID, '_webfire_keywords', true);
        $schema         = get_post_meta($post->ID, '_webfire_schema', true);
    }
    
    if (!empty($description)):
        ?>
        <meta name="description" content="<?php echo $description; ?>" />    
    <?php endif;
    
    if (!empty($keywords)):
        ?>
        <meta name="keywords" content="<?php echo $keywords; ?>" />    
    <?php
    endif;
    
    if ($viewport == 1):
        ?>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php
    endif;
    
    if (!empty($site_wide))
    {
        echo $site_wide;
    }      
    
    if (!empty($schema))
    {
        echo $schema;
    }
}

// editor page
add_action('edit_page_form', 'webfire_editor');
add_action('edit_form_advanced', 'webfire_editor');
function webfire_editor()
{
    global $post;

    $title          = get_post_meta($post->ID, '_webfire_title', true);
    $description    = get_post_meta($post->ID, '_webfire_description', true);
    $keywords       = get_post_meta($post->ID, '_webfire_keywords', true);
    $schema         = get_post_meta($post->ID, '_webfire_schema', true);
            
    ?>

    <style>
        .webfire div {margin:15px 8px;}
        .webfire div label {display:block;margin:8px 0px;}
        .webfire div input {min-width:80%;padding:8px;margin-left:10px;}
        .webfire div textarea {min-width:80%;padding:8px;margin-left:10px;}
        .not_set {border:1px solid red !important; background-color : #F4BAB0 !important;}
        .set {border:1px solid #209b07 !important; background-color : #D3F2D2 !important;}
    </style>

    <div class='webfire'>
        <h2 style='font-family: Arial,"Helvetica Neue",Helvetica,sans-serif;font-size:28px;border-bottom:2px solid #CBCFD4;color:#858585;'><img src="<?php echo plugins_url('images/logo-small.png', __FILE__); ?>" /> WebFire</h2>

        <div>
            <label>Title</label>
            <input type='text' value="<?php echo $title; ?>" name='webfire_title' id='webfire_title' spellcheck="true" class="<?php echo empty($title) ? 'not_set' : 'set'; ?>" />
        </div>

        <div>
            <label>Description</label>
            <input type='text' value="<?php echo $description; ?>" name='webfire_description' id='webfire_description' spellcheck="true" class="<?php echo empty($description) ? 'not_set' : 'set'; ?>" />
        </div>

        <div>
            <label>Keywords (comma separated e.g. video games, video game pool, video game reviews)</label>
            <input type='text' value="<?php echo $keywords; ?>" name='webfire_keywords' id='webfire_keywords' spellcheck="true" class="<?php echo empty($keywords) ? 'not_set' : 'set'; ?>" />
        </div>
        
        <div>
            <label>Schema Markup</label>
            <textarea name="webfire_schema_head"><?php echo $schema; ?></textarea>            
        </div>

    </div>

    <?php
}

// save post editor form
function webfire_save_editor($post_id, $post = null)
{
    if (!isset($post))
    {
        global $post;
    }
    
    // check the user
    $post_type = get_post_type_object($post->post_type);
    if (!current_user_can($post_type->cap->edit_post, $post_id))
    {
        return $post_id;
    }
    
    $title = $_POST['webfire_title'];
    
    
    // check sanitize and save the data
    empty($_POST['webfire_title']) ? delete_post_meta($post_id, '_webfire_title') : update_post_meta($post_id, '_webfire_title', $title);
    empty($_POST['webfire_description']) ? delete_post_meta($post_id, '_webfire_description') : update_post_meta($post_id, '_webfire_description', $_POST['webfire_description']);
    empty($_POST['webfire_keywords']) ? delete_post_meta($post_id, '_webfire_keywords') : update_post_meta($post_id, '_webfire_keywords', $_POST['webfire_keywords']);
    empty($_POST['webfire_schema_head']) ? delete_post_meta($post_id, '_webfire_schema') : update_post_meta($post_id, '_webfire_schema', $_POST['webfire_schema_head']);
    
//    echo $title . "<br/>";
//    echo get_post_meta($post_id, '_webfire_title', true);
//    exit();
}
add_action('save_post', 'webfire_save_editor');

// create plugin settings menu
add_action('admin_menu', 'webfire_create_menu');
function webfire_create_menu()
{
    // create new top-level menu
    add_menu_page('WebFire', 'WebFire', 'administrator', __FILE__, 'webfire_plugin_settings_page', plugins_url('/images/logo-tiny.png', __FILE__));

    // call register settings function
    add_action('admin_init', 'register_webfire_plugin_settings');
}

function register_webfire_plugin_settings()
{
    // register our settings
    register_setting('webfire-settings-group', 'webfire_home_title');
    register_setting('webfire-settings-group', 'webfire_home_keywords');
    register_setting('webfire-settings-group', 'webfire_home_description');
    register_setting('webfire-settings-group', 'webfire_viewport');
    register_setting('webfire-settings-group', 'webfire_sitewide_head');
    register_setting('webfire-settings-group', 'webfire_schema_head');
}

function webfire_plugin_settings_page()
{
    ?>
    <div class="wrap">
        
        <h2 style='font-family: Arial,"Helvetica Neue",Helvetica,sans-serif;text-shadow:1px 1px 3px gray;font-size:28px;border-bottom:2px solid #CBCFD4'><img src="<?php echo plugins_url('images/logo-small.png', __FILE__); ?>" /> WebFire</h2>

        <form method="post" action="options.php">
            
            <?php settings_fields('webfire-settings-group'); ?>
            <?php do_settings_sections('webfire-settings-group'); ?>
            
            <p class='lead'><b>Use these settings to modify the main SEO tags on your homepage.</b>  To modify these tags on pages and posts, edit the page or post, and use the form below the text editor.</p>
            
            <table class="form-table">                
                <tr valign="top">
                    <th scope="row">Homepage Title</th>
                    <td>
                        <input type="text" name="webfire_home_title" value="<?php echo esc_attr(get_option('webfire_home_title')); ?>" />
                        <p style='max-width:400px;'><small>A brief title, containing the main keyword targeted on this page, up to 70 characters (e.g. Madison's Best Automotive Repair Shop)</small></p>
                    </td>
                </tr>

                <tr valign="top">
                    <th scope="row">Homepage Description</th>
                    <td>
                        <input type="text" name="webfire_home_description" value="<?php echo esc_attr(get_option('webfire_home_description')); ?>" />
                        <p style='max-width:400px;'><small>A short paragraph describing the page, containing the main keyword targeted on this page.</small></p>
                    </td>
                </tr>

                <tr valign="top">
                    <th scope="row">Homepage Keywords</th>
                    <td>
                        <input type="text" name="webfire_home_keywords" value="<?php echo esc_attr(get_option('webfire_home_keywords')); ?>" />
                        <p style='max-width:400px;'><small>Comma separated list of keywords (e.g. madison automotive, madison car repair, wisconsin automotive, etc)</small></p>
                    </td>
                </tr>
                
                <tr valign="top">
                    <th scope="row">Sitewide Head Script</th>
                    <td>
                        <textarea style="width:100%;" name="webfire_sitewide_head"><?php echo esc_attr(get_option('webfire_sitewide_head')); ?></textarea>
                        <p style='max-width:400px;'><small>Add additional scripts or tags to the <?php echo htmlentities("<head>"); ?>, for example, Google Analytics, or other tracking scripts.</small></p>
                    </td>
                </tr>
                
                <tr valign="top">
                    <th scope="row">Schema Markup</th>
                    <td>
                        <textarea style="width:100%;" name="webfire_schema_head"><?php echo esc_attr(get_option('webfire_schema_head')); ?></textarea>
                        <p style='max-width:400px;'><small>Add markup from WebFire's schema tool</small></p>
                    </td>
                </tr>
                
                <tr valign="top">
                    <th scope="row">Add Viewport Tag?</th>
                    <td>
                        <input type="checkbox" name="webfire_viewport" value="1" <?php echo esc_attr(get_option('webfire_viewport')) == "1" ? "checked" : ""; ?> />
                        <p style='max-width:400px;'><small>Use the viewport tag to set the initial scale of your page based on the device viewing the page (e.g. phone vs monitor).  To test, enable this setting, and view your site on a phone, and compare to a normal screen. Many themes already enable this tag, in which case, you won't see a change and can leave this disabled.</small></p>
                    </td>
                </tr>                
            </table>

            <?php submit_button(); ?>

        </form>
    </div>
<?php } ?>
